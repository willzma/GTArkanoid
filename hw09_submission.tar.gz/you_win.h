#ifndef YOU_WIN_BITMAP_H
#define YOU_WIN_BITMAP_H
extern const unsigned short you_win[36000];
#define YOU_WIN_WIDTH 240
#define YOU_WIN_HEIGHT 150
#endif