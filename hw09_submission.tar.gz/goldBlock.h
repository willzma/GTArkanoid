#ifndef GOLDBLOCK_BITMAP_H
#define GOLDBLOCK_BITMAP_H
extern const unsigned short goldBlock[128];
#define GOLDBLOCK_WIDTH 16
#define GOLDBLOCK_HEIGHT 8
#endif