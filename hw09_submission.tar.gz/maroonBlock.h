#ifndef MAROONBLOCK_BITMAP_H
#define MAROONBLOCK_BITMAP_H
extern const unsigned short maroonBlock[128];
#define MAROONBLOCK_WIDTH 16
#define MAROONBLOCK_HEIGHT 8
#endif