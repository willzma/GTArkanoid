#ifndef FLORIDA_BITMAP_H
#define FLORIDA_BITMAP_H
extern const unsigned short florida[36000];
#define FLORIDA_WIDTH 240
#define FLORIDA_HEIGHT 150
#endif