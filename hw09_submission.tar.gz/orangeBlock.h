#ifndef ORANGEBLOCK_BITMAP_H
#define ORANGEBLOCK_BITMAP_H
extern const unsigned short orangeBlock[128];
#define ORANGEBLOCK_WIDTH 16
#define ORANGEBLOCK_HEIGHT 8
#endif