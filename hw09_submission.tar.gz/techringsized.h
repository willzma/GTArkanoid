#ifndef TECHRINGSIZED_BITMAP_H
#define TECHRINGSIZED_BITMAP_H
extern const unsigned short techringsized[36000];
#define TECHRINGSIZED_WIDTH 240
#define TECHRINGSIZED_HEIGHT 150
#endif