#ifndef REDBLOCK_BITMAP_H
#define REDBLOCK_BITMAP_H
extern const unsigned short redBlock[128];
#define REDBLOCK_WIDTH 16
#define REDBLOCK_HEIGHT 8
#endif