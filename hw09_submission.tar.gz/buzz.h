#ifndef BUZZ_BITMAP_H
#define BUZZ_BITMAP_H
extern const unsigned short buzz[36000];
#define BUZZ_WIDTH 240
#define BUZZ_HEIGHT 150
#endif