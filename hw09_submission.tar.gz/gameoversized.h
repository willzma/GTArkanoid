#ifndef GAMEOVERSIZED_BITMAP_H
#define GAMEOVERSIZED_BITMAP_H
extern const unsigned short gameoversized[36000];
#define GAMEOVERSIZED_WIDTH 240
#define GAMEOVERSIZED_HEIGHT 150
#endif