#ifndef FOOTBALLSIZED3_BITMAP_H
#define FOOTBALLSIZED3_BITMAP_H
extern const unsigned short footballsized3[80];
#define FOOTBALLSIZED3_WIDTH 10
#define FOOTBALLSIZED3_HEIGHT 8
#endif