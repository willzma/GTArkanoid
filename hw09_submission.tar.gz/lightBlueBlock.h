#ifndef LIGHTBLUEBLOCK_BITMAP_H
#define LIGHTBLUEBLOCK_BITMAP_H
extern const unsigned short lightBlueBlock[128];
#define LIGHTBLUEBLOCK_WIDTH 16
#define LIGHTBLUEBLOCK_HEIGHT 8
#endif