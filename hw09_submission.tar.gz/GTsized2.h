#ifndef GTSIZED2_BITMAP_H
#define GTSIZED2_BITMAP_H
extern const unsigned short GTsized2[450];
#define GTSIZED2_WIDTH 30
#define GTSIZED2_HEIGHT 15
#endif