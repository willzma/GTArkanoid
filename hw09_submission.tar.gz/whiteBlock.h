#ifndef WHITEBLOCK_BITMAP_H
#define WHITEBLOCK_BITMAP_H
extern const unsigned short whiteBlock[128];
#define WHITEBLOCK_WIDTH 16
#define WHITEBLOCK_HEIGHT 8
#endif